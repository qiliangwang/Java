package com.imooc.example.springdtx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDbApplication.class, args);
	}
}
