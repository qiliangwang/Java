package com.immoc.example.springtx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTransJta2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringTransJta2Application.class, args);
	}
}
